CREATE DATABASE "order-service"
Grant All PRIVILEGES ON "order-service" to "admin";