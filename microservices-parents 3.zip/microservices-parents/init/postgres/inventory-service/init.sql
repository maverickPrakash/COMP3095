CREATE DATABASE "inventory-service"
Grant All PRIVILEGES ON "inventory-service" to "admin";