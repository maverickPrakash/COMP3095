rootProject.name = "microservices-parents"
include("product-service","order-service","inventory-service","discovery-service","api-gateway")